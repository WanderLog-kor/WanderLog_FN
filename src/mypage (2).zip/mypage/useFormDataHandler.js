import { useState, useCallback } from "react";

const useFormDataHandler = (initialData) => {
  // 초기 데이터 저장
  const initialFormData = {
    userid: "",
    username: "",
    email: "",
    profileImage: "/ProfileImg/anonymous.jpg",
    password: "",
    repassword: "",
    authCode: "",
    ...initialData, // 초기 데이터를 외부에서 전달받아 덮어씌움
  };

  // 상태 관리
  const [formData, setFormData] = useState(initialFormData);

  // 유저 정보 변경 취소 시 상태 초기화
  const resetFormData = useCallback(() => {
    setFormData({ ...initialFormData }); // 초기 상태로 복원
  }, [initialFormData]);

  // 특정 필드를 업데이트
  const updateFormData = useCallback((field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }, []);


  // 사용자 이름 변경 핸들러
  const handleUsernameChange = (e) => {
    const { value } = e.target;
    setFormData((prev) => ({ ...prev, username: value }));
    const validationResult = validateUsername(value); // 이름 유효성 검사
    setValidationMessages((prev) => ({
      ...prev,
      username: validationResult.message,
      usernameColor: validationResult.color, // 유효성 결과에 따라 메시지 업데이트
    }));
  };

    // 비밀번호 변경 핸들러
    const handlePasswordChange = (e) => {
      const { name, value } = e.target;
    
      // 상태를 업데이트
      setFormData((prev) => ({
        ...prev,
        [name]: value || "", // undefined일 경우 빈 문자열로 처리
      }));
    
      // 비밀번호 유효성 검증
      if (name === "password") {
        const validationResult = validatePassword(value);
        setValidationMessages((prev) => ({
          ...prev,
          password: validationResult.message,
          passwordColor: validationResult.color,
        }));
      }
    
      // 비밀번호 확인 로직
      if (name === "repassword") {
        if (formData.password !== value) {
          setValidationMessages((prev) => ({
            ...prev,
            repassword: "비밀번호 확인이 일치하지 않습니다.",
            repasswordColor: "validation-error",
          }));
        } else {
          setValidationMessages((prev) => ({
            ...prev,
            repassword: "비밀번호가 일치합니다.",
            repasswordColor: "validation-success",
          }));
        }
      }
    };
    

   // 이메일 변경 핸들러
   const handleEmailChange = (e) => {
    const { value } = e.target;
    setFormData((prev) => ({ ...prev, email: value }));
  
    const validationResult = validateEmail(value); // 이메일 유효성 검사
    setValidationMessages((prev) => ({
      ...prev,
      email: validationResult.message,
      emailColor: validationResult.color,
    }));
  
    resetAuthState(); // 이메일 변경 시 인증 상태 초기화
  };


  // 인증 코드 확인 핸들러
  const handleAuthCodeVerification = (e) => {
    e.preventDefault(); // 이벤트 기본 동작 방지
    handleVerifyAuthCode(formData.email, formData.authCode); // formData에서 email, authCode 전달
  };

  const handleSendAuthCode = (e) => {
    e.preventDefault();
    const email = formData.email; // formData에서 이메일 추출
    sendAuthCode(email); // 이메일 값만 전달
  };
  
    // 일반 입력값 변경 핸들러
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prev) => ({ ...prev, [name]: value }));
    };


  return {
    formData,
    setFormData,
    resetFormData, // 초기화 메서드 추가
    updateFormData,
    handleEmailChange,
    handleUsernameChange,
    handleChange,
    handlePasswordChange,
    handleAuthCodeVerification,
    handleSendAuthCode,
  };
};

export default useFormDataHandler;