import { useCallback } from "react";
import axios from "axios";

const useSaveChanges = ({
  formData,
  setUserData,
  setIsEditing,
  isEmailEditing,
  isAuthCodeVerified,
  setValidationMessages,
}) => {
  const handleSaveChanges = useCallback(async () => {
    try {
      // 이메일 인증 여부 확인
      if (isEmailEditing && !isAuthCodeVerified) {
        setValidationMessages((prev) => ({
          ...prev,
          email: "이메일 인증을 완료해야 변경할 수 있습니다.",
          emailColor: "validation-error",
        }));
        alert("이메일 인증을 완료해야 변경할 수 있습니다.");
        return;
      }

      // 서버로 변경된 데이터 전송
      await axios.put("http://localhost:9000/user/mypage/userupdate", formData, {
        withCredentials: true,
      });

      alert("변경 사항이 저장되었습니다.");
      setIsEditing(false);
      setUserData((prev) => ({ ...prev, ...formData })); // 저장된 변경 사항 반영
    } catch (err) {
      console.error("변경 사항 저장 중 오류 발생:", err);
      alert("변경 사항을 저장하는 중 오류가 발생했습니다.");
    }
  }, [formData, isEmailEditing, isAuthCodeVerified, setValidationMessages, setUserData, setIsEditing]);

  return { handleSaveChanges };
};

export default useSaveChanges;
