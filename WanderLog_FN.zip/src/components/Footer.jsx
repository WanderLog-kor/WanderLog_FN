const Footer = () => {
    return (
      <footer className="main-footer">

      </footer>
    );
  };
  
  export default Footer;
  